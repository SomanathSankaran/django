from django.shortcuts import render
from django.http import  HttpResponse
from meetings.models import Meeting
# Create your views here.
def welcome(request):
    return render(request,"website/welcome.html",{"message":"hi","num_meetings":Meeting.objects.count()})

def welcome_all(request):
    return render(request,"website/welcome.html",{"message":"hi","num_meetings":Meeting.objects.all()})

def nothing(request):
    return HttpResponse("this is the ",request)

def about(request):
    return HttpResponse("this is somanath ,I am a jack of all trades but master of none")