from django.contrib import admin

# Register your models here.

from .models import Meeting,Rooms

admin.site.register(Meeting)
admin.site.register(Rooms)
