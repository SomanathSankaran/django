from django.db import models
from datetime import time

# Create your models here.

class Rooms(models.Model):
    name=models.CharField(max_length=200)
    floor=models.IntegerField()
    room_no=models.IntegerField()
    def __str__(self):
        return "{} at {} for {}".format(self.name,self.floor,self.room_no)
class Meeting(models.Model):
    title=models.CharField(max_length=200)
    date=models.DateField()
    starttime=models.TimeField(default=time(9))
    duration=models.IntegerField(default=1)
    room=models.ForeignKey(Rooms,on_delete=models.CASCADE)
    def __str__(self):
        return "{} at {} for {}".format(self.title,self.starttime,self.duration)